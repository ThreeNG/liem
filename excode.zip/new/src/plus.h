#ifndef PLUS_H
#define PLUS_H

int plus(int, int);

#endif
