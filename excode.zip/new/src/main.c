#include "plus.h"
#include <stdio.h>
int main(void){
	int a, b;
	printf("input a b: ");
	scanf("%d %d",&a, &b);
	printf("a + b = %d\n", plus(a,b));
	return 0;
}
