#include "subtraction.h"

int subtraction(int a, int b)
{
	// TODO: implement this function
	
	return a-b;
}
