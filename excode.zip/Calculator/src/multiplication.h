#ifndef __MULTIPLICATION_H__
#define __MULTIPLICATION_H__

int multiplication(int a, int b);

#endif/*  __MULTIPLICATION_H__ */