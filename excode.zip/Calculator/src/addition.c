#include "addition.h"

int addition(int a, int b)
{
	// TODO: implement this function
	
	return a+b;
}
