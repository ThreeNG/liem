#include "division.h"

int division(int a, int b)
{
	// TODO: implement this function
	
	return a/b;
}
