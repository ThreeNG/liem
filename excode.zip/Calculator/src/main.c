#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "addition.h"
#include "subtraction.h"
#include "multiplication.h"
#include "division.h"

/*
#define KEY "Enter the calculator Operation you want to do:"

void calculator_operations();
*/

int main(int argc, char* argv[])
{
	int a;
	int b;
	char calc_ops[100];
	
	if (argc > 3) {
		a = atoi(argv[1]);
		b = atoi(argv[2]);
		strcpy(calc_ops, argv[3]);
	}
	else {
		printf("Usage: %s num1 num2\n", argv[0]);
		printf("Example: %s 3 3\n", argv[0]);
		return 1;
	}
   
	switch(calc_ops[0]) {
		case 'a': 
			printf("%d + %d = %d \n", a, b, addition(a, b));
			break;

		case 's': 
			printf("%d - %d = %d \n", a, b, subtraction(a, b));
			break;

		case 'm': 
			printf("%d + %d = %d \n", a, b, multiplication(a, b));
			break;

		case 'd': 
			printf("%d + %d = %d \n", a, b, division(a, b));
			break;

/*      case 'm': modulus();
			break;

		case 'f': factorial();
			break;

		case 'p': power();
			break; 
		
		case 'l': lcm(); // least common multiple
			*/

	}
		
	return 0;
}
