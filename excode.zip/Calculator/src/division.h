#ifndef __DIVISION_H__
#define __DIVISION_H__

int division(int a, int b);

#endif/*  __DIVISION_H__ */