#ifndef __ADDITION_H__
#define __ADDITION_H__

int addition(int a, int b);

#endif/*  __ADDITION_H__ */