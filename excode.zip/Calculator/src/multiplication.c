#include "multiplication.h"

int multiplication(int a, int b)
{
	// TODO: implement this function
	
	return a*b;
}
