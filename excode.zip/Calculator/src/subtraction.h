#ifndef __SUBTRACTION_H__
#define __SUBTRACTION_H__

int subtraction(int a, int b);

#endif/*  __SUBTRACTION_H__ */